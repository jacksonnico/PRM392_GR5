package com.example.prm392_gr5.Ui.admin;

import androidx.appcompat.app.AppCompatActivity;

public class ViewBookingsActivity extends AppCompatActivity {
}
