package com.example.prm392_gr5.Data.repository;

public class ServiceRepository {
}
